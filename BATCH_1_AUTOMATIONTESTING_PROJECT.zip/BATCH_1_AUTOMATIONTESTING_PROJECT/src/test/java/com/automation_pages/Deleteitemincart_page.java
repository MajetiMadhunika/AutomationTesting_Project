package com.automation_pages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Deleteitemincart_page {
	Logger LOG = Logger.getLogger( Deleteitemincart_page.class.getName());
	 WebDriver driver;
	By shop = By.linkText("Shop");
	By addtobasket = By.xpath("/html/body/div[1]/div[2]/div/div/ul/li[3]/a[2]");
	By opencart = By.xpath("//*[@id=\"content\"]/div[2]/a");
	By remove= By.xpath("/html/body/div[1]/div[2]/div/div/div/div/div[1]/form/table/tbody/tr[1]/td[1]/a");
	
	public Deleteitemincart_page(WebDriver driver) 
	{
		this.driver =driver;
	}
	// add to  cart
		public void automation_addtocart()  {
			
			driver.findElement(shop).click();
			driver.findElement(addtobasket).click();
			LOG.info(" addded to  the cart ");	
		}

	// open cart
	public void automation_cartopen() {
	
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(opencart).click();
	
		LOG.info(" opened the cart ");
	}
	
	// delete item from the cart
	public void automation_removeitem() {
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
		driver.findElement(remove).click();
		LOG.info("product is deleted form the cart");
	}
	public void quit() throws Exception
	{
		Thread.sleep(2000);
		driver.close();
	}
}
