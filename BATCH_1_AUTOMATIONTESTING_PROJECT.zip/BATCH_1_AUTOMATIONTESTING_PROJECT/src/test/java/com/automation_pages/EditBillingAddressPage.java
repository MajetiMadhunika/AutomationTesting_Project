package com.automation_pages;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class EditBillingAddressPage {
	WebDriver driver;
	By Myaccount=By.linkText("My Account");
	By Username=By.id("username");
	By Password=By.id("password");
	By login=By.xpath("//input[@name='login']");
	By Address=By.linkText("Addresses");
	By editbilling=By.xpath("//a[@href='http://practice.automationtesting.in/my-account/edit-address/billing']");
	By firstname=By.id("billing_first_name");
	By lastname=By.id("billing_last_name");
	By company=By.id("billing_company");
	By Phone=By.id("billing_phone");
	By address1=By.id("billing_address_1");
	By address2=By.id("billing_address_2");
	By city=By.id("billing_city");
	By pstcode=By.id("billing_postcode");
	By saveaddress=By.xpath("//input[@type='submit']");
	By billing=By.xpath("//div[@class='woocommerce-message']");
	public EditBillingAddressPage(WebDriver driver) 
	{
		this.driver =driver;
	}
	
	//To enter login credentials
	public void loginCredentials(String user, String password) {
		driver.findElement(Myaccount).click();
		driver.findElement(Username).sendKeys(user);
		driver.findElement(Password).sendKeys(password);
		driver.findElement(login).click();
	}
	//To click on address
	public void clickAddresses() {
		driver.findElement(Address).click();
	}
	//To edit billing address
	public void editBilling() {
		driver.findElement(editbilling).click();
	}
	//To fill billing details
	public void fillDetails() {
		
		driver.findElement(firstname).clear();
		driver.findElement(firstname).sendKeys("Bhargavi");
		driver.findElement(lastname).clear();
		driver.findElement(lastname).sendKeys("Nagalla");
		driver.findElement(company).clear();
		driver.findElement(company).sendKeys("cts");
		driver.findElement(Phone).clear();
		driver.findElement(Phone).sendKeys("1223678912");
		driver.findElement(address1).clear();
		driver.findElement(address1).sendKeys("2-300");
		driver.findElement(address2).clear();
		driver.findElement(address2).sendKeys("kumar naga");
		driver.findElement(city).clear();
		driver.findElement(city).sendKeys("Hyderabad");
		driver.findElement(pstcode).clear();
		driver.findElement(pstcode).sendKeys("456789");
		
	}
	//To save address
	public void clickSaveAddresses() {
		driver.findElement(saveaddress).click();
	}
	//Assert
	public void AssertBilling() {
		String a = driver.findElement(billing).getText();
		Assert.assertEquals("Address changed successfully.",a);
		System.out.println("Billing saved Successfully");
	}
	//To take screenshot
	public void Screenshot() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("\\Screenshots\\editbillingaddress.png"));
	}
	//To close the browser window
		public void quit() {
			driver.close();
		}
	
}


