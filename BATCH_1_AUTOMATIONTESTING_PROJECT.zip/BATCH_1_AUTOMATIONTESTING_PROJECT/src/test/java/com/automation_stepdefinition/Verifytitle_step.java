package com.automation_stepdefinition;

import com.automation_pages.Login_page;
import com.automation_pages.Verify_title_page;
import com.baseclass.LibraryClass;
import com.seleniumutil.selenium_util;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Verifytitle_step extends LibraryClass {

	Login_page login;
	Verify_title_page verify;
	
	  selenium_util util;
	  
	
	@Given("^launch the automation appliction$")
	public void launch_the_automation_appliction() throws Throwable {
		launchApp();
	}

	@Then("^get the title name$")
	public void get_the_title_name() throws Throwable {
	    verify = new Verify_title_page(driver);
	    verify.automation_getacttitle();
	    
	}

	@Then("^compare with expected title$")
	public void compare_with_expected_title() throws Throwable {
		 verify = new Verify_title_page(driver);
		 verify.automation_verifytitle();
		 driver.close();
	}

}
